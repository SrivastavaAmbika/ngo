$(window).on('scroll', function() {
    //if($(window).scrollTop()){
    if ($(window).scrollTop() > 143) {

        $('.header').addClass('abc1');
    } else {
        $('.header').removeClass('abc1')
    }
});
